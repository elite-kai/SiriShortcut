//
//  AppDelegate.h
//  SiriShortcut
//
//  Created by 翱顿科技 on 2020/12/1.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

