//
//  ViewController.m
//  SiriShortcut
//
//  Created by 翱顿科技 on 2020/12/1.
//

#import "ViewController.h"
#import "StudyIntent.h"
#import <IntentsUI/IntentsUI.h>

@interface ViewController ()<INUIAddVoiceShortcutViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)testAction:(id)sender {
    StudyIntent *studyIntent = [[StudyIntent alloc] init];
    studyIntent.content = @"学习时间";
    studyIntent.suggestedInvocationPhrase = @"open the door";

    INShortcut *shortCut = [[INShortcut alloc] initWithIntent:studyIntent];
    
    INUIAddVoiceShortcutViewController *voiceShortcutVC = [[INUIAddVoiceShortcutViewController alloc] initWithShortcut:shortCut];
    voiceShortcutVC.delegate = self;
    [self presentViewController:voiceShortcutVC animated:YES completion:nil];
}

-(void)addVoiceShortcutViewControllerDidCancel:(INUIAddVoiceShortcutViewController *)controller
{
    [controller dismissViewControllerAnimated:YES completion:nil];
}

-(void)addVoiceShortcutViewController:(INUIAddVoiceShortcutViewController *)controller didFinishWithVoiceShortcut:(INVoiceShortcut *)voiceShortcut error:(NSError *)error
{
    [controller dismissViewControllerAnimated:YES completion:nil];
}


@end
