//
//  IntentViewController.h
//  StudyUI
//
//  Created by 翱顿科技 on 2020/12/1.
//

#import <IntentsUI/IntentsUI.h>

@interface IntentViewController : UIViewController <INUIHostedViewControlling, INUIHostedViewSiriProviding>

@end
