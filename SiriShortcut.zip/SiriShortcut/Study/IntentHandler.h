//
//  IntentHandler.h
//  Study
//
//  Created by 翱顿科技 on 2020/12/1.
//

#import <Intents/Intents.h>

@interface IntentHandler : INExtension

@end
